# Emerald Engine v2 — upgrade notes

This release focuses on two things: making the engine and its scripting
language measurably faster, and adding the gameplay systems a small engine
needs most (shadows, particles, audio, prefabs). Every number below was
measured on this codebase; every feature is exercised by the self-test suite
(`./build/emerald-engine --selftest`, 16 tests) plus a real-GL render smoke
test run under Mesa.

## 1. Emerald interpreter performance

The vendored interpreter in `third_party/emerald/` (and the patch in
`emerald-interpreter-perf.patch`, which applies to the upstream language
repo) was optimized without changing any language semantics — the language's
own 11-test suite still passes, and engine test T16 specifically guards the
trickiest change.

Measured with interleaved A/B runs (best of N) against the unmodified
interpreter, Release builds, same machine:

| Workload | Before | After | Speedup |
|---|---|---|---|
| Tight numeric loop, 1M iterations (fib-style) | 1.11 s | 0.76 s | **1.47×** |
| Class construction + method calls, 60k objects | 1.68 s | 1.27 s | **1.32×** |
| String building + interpolation, 30k rounds | 0.082 s | 0.058 s | **1.41×** |
| Growing an array by index, 50k appends | 46.8 s | 0.07 s | **O(n²) → O(n)** |

What changed:

* **Value got 8 bytes smaller.** Builtin functions were stored inline in
  every `Value` (a `std::function` + a `std::string` name); they now live
  behind one `shared_ptr`, which makes every copy/move of every value cheaper.
* **Environments are flat vectors.** Local scopes replaced
  `unordered_map + insertion-order vector` with a single
  `vector<pair<name, Value>>`. Scopes are almost always tiny, so a linear
  scan beats hashing, and declaration order comes for free.
* **Object fields are flat vectors** for the same reason.
* **Arguments are only deep-cloned when the callee can mutate them.**
  Builtins receive arguments read-only, so the interpreter no longer clones
  them. This is the fix that removed the quadratic append: `arr[len(arr)] = x`
  used to deep-copy the whole array just to call `len()`.
* **Loop bodies reuse their environment frame** between iterations when
  nothing captured it (checked via `use_count`), instead of allocating a new
  scope per iteration. Escaping state still gets its own frame — see
  self-test T16.
* **Binary operators memoize their dispatch** (an `int` opcode cached on the
  AST node) with fast paths for int arithmetic.

## 2. Renderer

The frame loop was rebuilt around an explicit draw list:

* **World matrices** are computed once per frame in a single hierarchy pass
  (previously recomputed per entity per draw by walking parent chains).
* **Lights are gathered once per frame** (previously per entity).
* **Frustum culling** (Gribb/Hartmann plane extraction, bounding-sphere test)
  skips off-screen entities; the render smoke test culls 24 of 50.
* **Draw items are sorted by (shader, mesh)** so state changes collapse —
  the smoke-test scene renders with a single `glUseProgram`.
* **Uniform locations are cached per shader** instead of
  `glGetUniformLocation(string)` per draw, and per-frame uniforms are set
  once per program bind, not per object.
* **Bone matrices upload with one `glUniformMatrix4fv`** instead of one call
  per bone.
* **Directional shadow mapping**: 2048² depth map, 3×3 PCF, slope-scaled
  bias, front-face culling in the depth pass, correct for skinned meshes via
  a dedicated skinned depth shader. Toggle per light ("Cast Shadows").
* **Per-camera exponential fog** (color + density in the Camera inspector).
* **Instanced billboard particles** (additive and alpha-blended groups,
  alpha group sorted back-to-front, soft circular falloff).
* **`RenderStats`** (draw calls, culled count, shader binds, particles,
  shadow draws, CPU ms) surfaced live in the editor status bar.

## 3. Physics

* **Sweep-and-prune broadphase** along X replaces the all-pairs O(n²) test,
  and world AABBs are computed once per pass instead of per candidate pair.
* **Restitution**: `RigidBody.bounciness` (0–1) reflects the closing
  velocity on impact, with a small threshold so resting contact still
  settles. Self-test T14 drops a bouncy body and asserts the rebound.

## 4. New engine systems

* **Particle systems** — a full authoring component (rate, lifetime & jitter,
  cone spread, gravity, drag, size/color over lifetime, additive/alpha, max
  pool) simulated on the CPU and rendered instanced. Live preview while
  editing; `particles_burst/emit/rate` natives from scripts.
* **Audio** — vendored [miniaudio] (public domain), initialized with a
  device when one exists and a **silent null backend when headless**, so
  servers and CI behave identically. `AudioSource` component: clip path,
  volume, loop, play-on-start, 3D spatial with min/max distance; the
  listener follows the main camera. Natives: `audio_play/stop/is_playing/
  volume`, `play_sound` one-shots.
* **Prefabs** — right-click any entity → *Save as Prefab* writes a
  `prefabs/*.prefab.json` containing that subtree; double-clicking it in the
  Assets panel (or `spawn_prefab(path)` from a script) instantiates it with
  fresh ids, remapped hierarchy, and — during Play mode — scripts started
  and audio playing. Self-test T12 covers the round trip.
* **Tags** — a free-form `tag` per entity, editable in the Inspector,
  searchable via `find_by_tag(tag)` (returns an array of ids).
* **Time scale** — `set_time_scale(s)` scales Play-mode `dt` for slow-motion
  or pause-like effects (`get_time_scale()` to read).

## 5. Editor

New Inspector sections for Particle System and Audio Source (with in-editor
audio preview), a Tag field, camera Fog controls, light "Cast Shadows",
RigidBody "Bounciness", new Add Component entries, *Save as Prefab* in the
hierarchy context menu, prefab instantiation from the Assets panel, and a
renderer-stats readout in the status bar.

## 6. Tests

`--selftest` grew from 10 to 16 checks:

* T11 particle emission/aging/reclamation
* T12 prefab save + instantiate (id remap, hierarchy, components)
* T13 `find_by_tag` through a real script VM
* T14 physics restitution
* T15 audio init + generated-WAV playback (headless-safe)
* T16 interpreter loop-frame reuse preserves escaping per-iteration state

A separate GPU smoke test (not shipped) rendered the new pipeline under
Mesa/Xvfb: 26 draws, 24 culled, 1 shader bind, 26 shadow draws, 40 particles,
zero GL errors.

# v6 — the last four gaps: mesh physics, rollback, encryption, NAT traversal

The v5 needed four things left:
convex/mesh colliders, rollback netcode, encrypted transport, and NAT
traversal. v6 does all four, plus a light-probe upgrade. Everything below is
verified by the self-test suite (now 41 checks) or the GL smoke test, and the
crypto is checked against the published RFC vectors — I did not invent a
cipher.

## 1. Convex-hull + triangle-mesh colliders

The collider set gains two Jolt geometry shapes:

* **Convex** — a hull built from any mesh's vertices (`ConvexHullShape`).
  Works on dynamic bodies, so an arbitrary mesh can tumble and settle
  realistically.
* **Mesh** — the exact triangles of a mesh (`MeshShape`). Jolt only allows
  triangle meshes on non-dynamic bodies, so a dynamic Mesh collider is
  automatically demoted to kinematic with a one-time warning (use Convex for
  a dynamic body). Ideal for detailed static level geometry.

Both pull geometry from an optional collision-mesh override, or the entity's
render mesh by default, and the physics shape-cache keys on the mesh id so
swapping meshes rebuilds the shape.

Test T36 drops a dynamic convex sphere-hull onto a static triangle-mesh floor
and confirms it falls, then rests at the correct height; it also asserts a
dynamic Mesh collider is safely demoted to kinematic rather than crashing.

## 2. Rollback netcode (deterministic, GGPO-style)

Scope stated up front: rollback runs over a **deterministic gameplay
simulation** — a fixed-60 Hz integrator of per-player entity state driven
purely by input bitfields — which is exactly the model competitive games use.
It is not the full Jolt solver rolled back (cross-machine determinism of a
general contact solver is a separate hard problem; Jolt bodies replicate
through the v5 snapshot path instead). What v6 adds:

* a fixed timestep with a **ring buffer of saved states**;
* **local input applied immediately** (zero input latency);
* **remote input predicted** (repeat-last) and corrected on arrival;
* on a misprediction, the sim **rolls back** to the confirmed frame, replaces
  the input, and **resimulates** to the present;
* a **state hash** for cheap desync detection between peers.

The tests are the real proof of a rollback system. **T37** runs a
ground-truth session (all inputs known immediately) beside a predicting
session (one player's inputs arrive four frames late, including a surprise
direction reversal that *forces* a rollback), and asserts the predictor's
state hash ends **bit-identical** to ground truth — i.e. the rollback
produced exactly the state as if nothing had been mispredicted. **T38**
confirms the complement: a constant input is predicted perfectly, so after the
unavoidable initial seed the rollback count **freezes** — no wasted
resimulation when predictions are right.

## 3. Encrypted transport (X25519 + ChaCha20-Poly1305)

Every datagram is now optionally sealed with real, standard authenticated
encryption:

* **X25519** (RFC 7748) ephemeral key exchange: each peer generates a
  keypair, they swap public keys in a short plaintext handshake, and derive a
  shared secret — with a per-direction key so the two directions never share a
  (key, nonce) pair.
* **ChaCha20-Poly1305** (RFC 8439) AEAD on every packet: a 96-bit nonce
  (counter + direction) and a 128-bit Poly1305 tag, with the outer header as
  associated data and a replay window on the receive side.
* Once encryption is on, **plaintext game packets are rejected** — only the
  key-exchange packets are allowed in the clear.

Crucially, the implementation is **verified against the RFC known-answer
vectors** in `cryptoSelfTest()` (the X25519 test vector and DH round, the
ChaCha20-Poly1305 AEAD vector, and tamper detection) — the build's own test
refuses to pass unless our code reproduces the standards exactly. **T39**
then drives a full encrypted join over the socket layer: the channel comes up
secure, messages round-trip sealed, and a client with encryption *off* is
correctly refused by an encrypted server.

Honest scope: this is confidentiality + integrity + replay resistance on the
wire, not a full TLS/DTLS stack — no certificate PKI, no cross-session forward
secrecy. For a shipping title you would add identity verification on top; for
protecting gameplay traffic it is genuine crypto, not obfuscation.

## 4. NAT traversal (rendezvous + UDP hole punching)

Peer-to-peer across home routers needs NAT traversal, and v6 implements the
standard approach:

* a lightweight **rendezvous server** matches peers by room code and records
  the public (reflexive) endpoint it *sees* each peer arrive from;
* it relays each peer's endpoint to the other, and both peers then **fire
  punch packets** at that endpoint to open their NAT mappings;
* once a punch is acknowledged a **direct path** exists, held open by
  keepalives; if punching fails (symmetric NAT), traffic **falls back to a
  relay** through the rendezvous.

Test T40 stands up a rendezvous server and two peers (three engine instances
in one process), and verifies the full protocol: both register, get matched,
exchange endpoints, punch, reach the Connected phase, and *stay* connected
through keepalives. The honest limit: loopback has no NAT, so the test
exercises the matchmaking/endpoint-exchange/punch/keepalive **protocol** —
which is the part CI can verify — while true cone-vs-symmetric behavior needs
real routers.

## 5. Light probes (irradiance blending)

v5's reflection probes used a single nearest pick. v6 adds a **Light Probe**
mode: moving objects select the **two nearest** captured probes and **blend
their irradiance by inverse distance**, so ambient light transitions smoothly
as an object moves between probes instead of popping. Specular still uses the
nearest probe. Test T41 covers the selection and blend-weight math (midpoint
≈ 0.5, correct ordering and dominance near each probe, single-probe and
out-of-range cases) plus serialization.

## The ledger, essentially closed

Every headline gap this project set out against is now addressed and tested:
GI + IBL rendering, the full Jolt collider set with joints and CCD,
loss-tolerant **encrypted** multiplayer that can **traverse NAT**,
**deterministic rollback** for gameplay, and a gigabyte-scale asset pipeline —
in ~15k readable lines, each subsystem proven by a test you can run in one
command.

## 1. Joints, CCD, capsules (Jolt, fully exposed)

* **Joint component** with five Jolt constraint types — Fixed, Point
  (ball), Hinge, Slider, Distance — anchored to another entity or to the
  world, with local anchors/axes, optional limits (degrees for hinges,
  meters for sliders), and runtime breaking (`joint_break(id)`).
  Constraints are reconciled like bodies: edit a parameter and the joint
  rebuilds; destroy a participating body and its joints are removed first
  (the order Jolt requires).
* **Continuous collision detection** per rigidbody (`ccd` checkbox /
  `set_ccd`), mapping to Jolt's LinearCast motion quality.
* **Capsule colliders** with radius + height.

Test T31: a hinge pendulum swings under gravity while its arm length stays
within 8 cm of spec over 240 steps; a distance joint holds two yanked
bodies at 2 m ± 12 cm; breaking the hinge frees the bob. Test T32: a
12 cm sphere at **220 m/s** (3.6 m per step — far beyond tunneling range)
stops at a 10 cm-thin wall with CCD on, and a capsule settles on the floor
at exactly bottom-of-capsule height, grounded.

## 2. Netcode v2: built for lossy networks

The v4 transport was honest LAN-grade. v5 rebuilds it into something you
can run over real internet conditions, and proves it with a built-in
simulator (`net_simulate(loss, latencyMs, jitterMs)`) that drops, delays,
and jitters outgoing packets:

* **Reliable ordered channel** over UDP: sequence numbers, cumulative acks
  piggybacked on every packet, RTT-adaptive retransmission with backoff,
  duplicate suppression, in-order delivery with out-of-order buffering.
  The join handshake (chunked scene transfer), messages, and spawns all
  ride it.
* **Sequenced delta snapshots**: stale snapshots are dropped; each client
  receives only entities that actually changed, plus a 1 Hz keyframe.
* **Interpolation**: clients buffer stamped snapshots and render ~100 ms
  behind an estimated server clock, so motion stays smooth through jitter
  and loss instead of teleporting.
* **Client ownership**: the server can grant a client authority over an
  entity (`net_set_owner`); the owner streams its transform on a sequenced
  channel, the server validates the sender, and the owner's local copy is
  never fought by incoming snapshots.
* Per-client **session tokens** (cheap spoof/stale rejection), ping/RTT
  measurement, and live stats (`net_stats`).

**Test T33** runs a full join plus 40 reliable messages each way under
**25% packet loss with 60 ± 40 ms jitter in both directions**: delivery is
100%, exactly once, in order (measured resend rate confirms the loss was
real). **Test T34** verifies interpolated motion never steps more than
0.24 m per tick under jitter (teleporting would be meters), delta
snapshots go >80% silent when nothing moves, and a client-owned entity
drives the server copy to within 5 cm while the client's copy stays
untouched.

Still true, still documented: no encryption/DTLS, no NAT punchthrough, no
rollback prediction.

## 3. Image-based lighting + reflection probes

* The procedural **sky becomes an environment map**: captured to a
  cubemap, cosine-convolved into an irradiance map (diffuse), and
  GGX-importance-prefiltered across five roughness mips (specular), with
  Karis' analytic environment BRDF in the shader — so PBR materials get
  real ambient reflections, and metals finally look like metal. The
  capture refreshes automatically whenever the sky or sun changes.
* **Reflection probes** as a component: each probe renders the actual
  scene into its own cubemap (six 90° views, post-free, recursion-guarded)
  and produces both prefiltered specular and irradiance — so it doubles
  as a local light probe for dynamic objects. Per-item nearest-probe
  selection within range, sky IBL as fallback; capture from the Lighting
  menu, the inspector, or automatically on Play.
* Priority chain, stated plainly: baked lightmap wins for static diffuse,
  IBL irradiance for everything else, hemisphere as the no-GPU fallback;
  IBL specular layers on top of both.

Test T35 covers probe selection (nearest-in-range wins, out-of-range and
uncaptured excluded) and serialization. The GL smoke test captures a real
probe next to a chrome sphere (metallic 1.0, roughness 0.05) with **zero
GL errors** and asserts the rendered sphere pixel visibly changes when IBL
is toggled — reflections provably reach the screen.

## The ledger, updated honestly

Closed by v5: joints/CCD exposure, IBL and probes, and netcode that
survives loss and jitter.

# v4 — the "ecosystem" pass: PhysX-class physics, networking, baked GI, asset pipeline, hardening

The v3 notes ended by naming what an engine can't get from single features:
a real physics engine, networking, baked GI, an asset pipeline that scales,
and hardening. v4 goes at exactly that list. As always: every claim below is
tested (`--selftest`, now 30 checks) or measured on this machine.

## 1. Physics: Jolt (the real thing)

The request was PhysX. Rather than imitate one, v4 vendors and fully
integrates **Jolt Physics** — the MIT-licensed engine that shipped Horizon
Forbidden West, and PhysX's peer in the modern-engine generation. The old
~200-line AABB solver is gone; `physicsStep` now reconciles the scene into a
Jolt world every tick:

* Dynamic, kinematic, and static bodies from the same components as before
  (nothing in scenes or scripts changes), with **restitution and the new
  `friction`** property, per-body gravity toggle, mass, and sensors
  (triggers) via Jolt's sensor bodies.
* **Rotated colliders finally work** — the old engine's biggest physics
  limitation — because Jolt's solver is shape-and-orientation aware.
* **Terrain becomes a real `HeightFieldShape`**, so bodies roll and settle
  on hills through the solver instead of a post-step clamp.
* Raycasts route through Jolt's narrow-phase query; grounded detection comes
  from contact normals via a thread-safe contact listener; contact events
  keep feeding `on_collision` exactly as before.
* Multithreaded stepping through Jolt's job system.

All 8 physics-touching self-tests (gravity, contacts, triggers, restitution,
terrain rest, raycast pick, player grounding, nav-over-colliders) passed on
Jolt without loosening a single threshold.

## 2. Baked global illumination

`Lighting → Bake Lightmaps` runs a real CPU lightmapper:

* Static geometry (per-entity **Static (GI)** flag) is charted into a
  lightmap atlas — one chart per triangle, shelf-packed, edge-dilated — and
  each entity gets a `uv2`-carrying mesh clone (vertex format gained a
  second UV channel).
* Every texel raytraces a **BVH of the static scene**: direct sun with
  shadow rays, cosine-hemisphere **sky light** (colors taken from the
  procedural sky so bakes match the view), and **N bounces of indirect
  diffuse** gathered from the previous pass.
* Multithreaded across all cores; the result saves as a PNG atlas plus
  `.emmesh` clones, all referenced by the scene file, so **bakes survive
  save/load** and ship with exported games.
* Both the classic lit shader and the PBR shader consume the lightmap
  (baked diffuse replaces realtime sun diffuse + ambient; specular stays
  realtime).

Test T27 is the proof of GI, not just shadowing: a probe under a roof reads
darker than one in the open, **and re-baking with one bounce measurably adds
light back into the shadowed probe** — that added energy is indirect
illumination.

## 3. Networking

`net_host(port)` / `net_join(ip, port)` from any script (or the natives
console). The model, stated honestly: **server-authoritative snapshot
replication over UDP** —

* Joining clients receive the full scene (chunked transfer with retry, so
  scenes of any size survive UDP's datagram limit), then **20 Hz transform
  snapshots** for entities flagged `netSync` (Inspector checkbox or
  `net_sync(id, on)`), smoothed on arrival.
* Bidirectional script messaging: `net_send(text)` /
  `net_poll() -> [from, text, ...]` — clients talk to the server, the
  server broadcasts; game logic decides what messages mean.
* Spawn/despawn packets, peer timeouts, clean leave notifications.
* Cross-platform sockets (POSIX + Winsock).

Test T28 runs a real server and a real client **as two engines in one
process over loopback**: handshake, full scene transfer, position
convergence after server-side movement, and message round-trips both ways.
This is LAN-grade multiplayer — there is no client prediction, rollback, or
encryption, and the docs say so.

## 4. Asset pipeline at gigabyte scale

Three pieces, all measured on a generated **940 MB** asset set (56 noisy
2048² PNGs + a 43 MB, 500k-triangle OBJ):

* **Binary import cache** (`assets/.emcache/`): decoded textures and parsed
  models are stored as validated raw blobs keyed to the source's
  mtime+size. Warm loads skip PNG decode and Assimp entirely:

  | | cold | warm (cache) | speedup |
  |---|---|---|---|
  | 56 textures (897 MB) | 3.4 s | **0.34 s** | ~10× (24× on a cold OS page cache) |
  | 500k-tri OBJ | 1.23 s | **0.013 s** | **95×** |
  | whole set | 4.7 s | **0.38 s** | **12×** |

  Stale or corrupt entries are detected and silently rebuilt (test T25c
  literally writes garbage into the cache and asserts recovery).
* **Async texture streaming**: in the editor and player, textures appear
  instantly as placeholders while worker threads decode; finished pixels
  upload on the main thread each frame. Big scenes stop blocking the UI.
* **`.empak` archives**: `emerald-engine --pack game.empak` packs the whole
  assets folder into one seekable archive; a `game.empak` next to the assets
  folder auto-mounts, and textures load straight from it.

## 5. Hardening

* The entire 30-test suite runs **clean under AddressSanitizer +
  UndefinedBehaviorSanitizer** (that run found and fixed real bugs,
  including an argument-evaluation-order bug that silently swapped X/Z in
  network snapshots and cached animation keys).
* **Chaos test T29** feeds the engine truncated JSON, wrong-typed fields,
  hierarchy cycles, missing assets, out-of-range navigation queries,
  zero-length raycasts, nonexistent prefabs, and scripts that fail to parse
  or throw at runtime — the engine must survive all of it, and does.
  Hierarchy cycles specifically can no longer hang `worldMatrix`.
* **Atomic file writes** everywhere (`temp + rename`): a crash mid-save can
  never truncate a scene, prefab, cache entry, or config.
* **Editor autosave** every 60 s to `scenes/.autosave.scene.json`.


## Rendering: PBR + HDR

* **PBR shader** (`shaders/pbr.shader.json`, plus a skinned variant):
  Cook-Torrance GGX specular, Smith geometry, Schlick Fresnel,
  metallic/roughness/AO properties, emissive, and **normal mapping without
  precomputed tangents** (screen-space derivative cotangent frame — works on
  any imported mesh). Same shadow/fog interface as the classic lit shader;
  materials pick it by shader path, and its properties appear as sliders in
  the Inspector automatically.
* **HDR pipeline**: the scene renders into an RGBA16F target, a soft-knee
  bright pass extracts highlights at half resolution, two separable Gaussian
  blur iterations spread them, and a composite applies exposure, bloom,
  **ACES filmic tonemapping**, and gamma. Per-camera: exposure, bloom
  on/off/threshold/intensity. Works identically into editor viewports and
  the standalone player.
* **Procedural sky**: gradient dome + sun disc derived from the directional
  light, rendered after opaques (early-z). Its three colors also drive the
  PBR **hemisphere ambient**, so bounce light matches the sky.
* **Shadow texel snapping**: the shadow camera now moves in texel-sized
  steps, eliminating the edge shimmer noted in v2's known limitations.

## Animation: state machines + IK

* **AnimStateMachine component**: named states (clip, speed, loop) and
  transitions with conditions — float `>` / `<`, bool true/false, or
  one-shot triggers — evaluated every frame, with per-transition crossfade
  time. Editable in the Inspector (state list, transition rows), serialized
  with the scene, driven from scripts:
  `anim_set_float/set_bool/trigger/anim_play/anim_state`.
* **Crossfade blending**: switching clips snapshots the current pose and
  smoothstep-blends position/scale (lerp) and rotation (quaternion slerp)
  into the new clip — no pops.
* **Runtime IK**: a damped **CCD solver** (`solveCCD`) runs after animation
  sampling; scripts call `ik_reach(id, bone, x, y, z, chainLen)` to pin a
  hand/foot/look target and `ik_stop` to release. Test T19 verifies the tip
  lands within 5 cm of a reachable target.

## World: terrain + navigation

* **Terrain component**: deterministic value-noise fBm heightfield (size,
  resolution, amplitude, seed, octaves, frequency — all Inspector-editable
  with live rebuild), generated mesh with analytic normals, edge fade so
  patches sit flush. Physics treats terrain as ground (bodies rest and
  bounce on it — test T21), and scripts can query `terrain_height(x, z)`.
* **Navigation**: `nav_build(cellSize)` rasterizes static colliders into a
  walkable grid (ground slabs stay walkable, obstacles in the agent's height
  band block); `nav_path` runs A* with octile heuristic, 8-way movement
  with corner-cut prevention, and collinear simplification. Test T20 proves
  paths route around walls without touching blocked cells.

## Workflow

* **Undo/redo** (Ctrl+Z / Ctrl+Y, Edit menu): the editor snapshots the whole
  scene automatically whenever it settles after a change (gizmo drags,
  inspector edits, creates/deletes/reparents — all captured by one
  mechanism), with a 64-step history. Snapshot restore is exact (test T18).
* **Script hot-reload**: while playing, edited `.em` files are detected
  within 0.5 s and reloaded in place — iterate on gameplay without leaving
  Play mode.
* **Profiler window**: 180-frame frame-time graph with average/peak, plus
  the renderer's live counters (draws, culled, shader binds, shadow draws,
  particles, CPU ms) and nav-grid stats.

## Tests

`--selftest` grew from 16 to 22: T17 state machines + crossfade, T18
undo snapshots, T19 CCD IK convergence, T20 A* obstacle avoidance, T21
terrain heightfield + physics rest, T22 PBR shader asset round-trip.


[miniaudio]: https://miniaud.io
