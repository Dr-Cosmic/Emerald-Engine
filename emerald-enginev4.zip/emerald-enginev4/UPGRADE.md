# Emerald Engine v2 — upgrade notes

This release focuses on two things: making the engine and its scripting
language measurably faster, and adding the gameplay systems a small engine
needs most (shadows, particles, audio, prefabs). Every number below was
measured on this codebase; every feature is exercised by the self-test suite
(`./build/emerald-engine --selftest`, 16 tests) plus a real-GL render smoke
test run under Mesa.

## 1. Emerald interpreter performance

The vendored interpreter in `third_party/emerald/` (and the patch in
`emerald-interpreter-perf.patch`, which applies to the upstream language
repo) was optimized without changing any language semantics — the language's
own 11-test suite still passes, and engine test T16 specifically guards the
trickiest change.

Measured with interleaved A/B runs (best of N) against the unmodified
interpreter, Release builds, same machine:

| Workload | Before | After | Speedup |
|---|---|---|---|
| Tight numeric loop, 1M iterations (fib-style) | 1.11 s | 0.76 s | **1.47×** |
| Class construction + method calls, 60k objects | 1.68 s | 1.27 s | **1.32×** |
| String building + interpolation, 30k rounds | 0.082 s | 0.058 s | **1.41×** |
| Growing an array by index, 50k appends | 46.8 s | 0.07 s | **O(n²) → O(n)** |

What changed:

* **Value got 8 bytes smaller.** Builtin functions were stored inline in
  every `Value` (a `std::function` + a `std::string` name); they now live
  behind one `shared_ptr`, which makes every copy/move of every value cheaper.
* **Environments are flat vectors.** Local scopes replaced
  `unordered_map + insertion-order vector` with a single
  `vector<pair<name, Value>>`. Scopes are almost always tiny, so a linear
  scan beats hashing, and declaration order comes for free.
* **Object fields are flat vectors** for the same reason.
* **Arguments are only deep-cloned when the callee can mutate them.**
  Builtins receive arguments read-only, so the interpreter no longer clones
  them. This is the fix that removed the quadratic append: `arr[len(arr)] = x`
  used to deep-copy the whole array just to call `len()`.
* **Loop bodies reuse their environment frame** between iterations when
  nothing captured it (checked via `use_count`), instead of allocating a new
  scope per iteration. Escaping state still gets its own frame — see
  self-test T16.
* **Binary operators memoize their dispatch** (an `int` opcode cached on the
  AST node) with fast paths for int arithmetic.

## 2. Renderer

The frame loop was rebuilt around an explicit draw list:

* **World matrices** are computed once per frame in a single hierarchy pass
  (previously recomputed per entity per draw by walking parent chains).
* **Lights are gathered once per frame** (previously per entity).
* **Frustum culling** (Gribb/Hartmann plane extraction, bounding-sphere test)
  skips off-screen entities; the render smoke test culls 24 of 50.
* **Draw items are sorted by (shader, mesh)** so state changes collapse —
  the smoke-test scene renders with a single `glUseProgram`.
* **Uniform locations are cached per shader** instead of
  `glGetUniformLocation(string)` per draw, and per-frame uniforms are set
  once per program bind, not per object.
* **Bone matrices upload with one `glUniformMatrix4fv`** instead of one call
  per bone.
* **Directional shadow mapping**: 2048² depth map, 3×3 PCF, slope-scaled
  bias, front-face culling in the depth pass, correct for skinned meshes via
  a dedicated skinned depth shader. Toggle per light ("Cast Shadows").
* **Per-camera exponential fog** (color + density in the Camera inspector).
* **Instanced billboard particles** (additive and alpha-blended groups,
  alpha group sorted back-to-front, soft circular falloff).
* **`RenderStats`** (draw calls, culled count, shader binds, particles,
  shadow draws, CPU ms) surfaced live in the editor status bar.

## 3. Physics

* **Sweep-and-prune broadphase** along X replaces the all-pairs O(n²) test,
  and world AABBs are computed once per pass instead of per candidate pair.
* **Restitution**: `RigidBody.bounciness` (0–1) reflects the closing
  velocity on impact, with a small threshold so resting contact still
  settles. Self-test T14 drops a bouncy body and asserts the rebound.

## 4. New engine systems

* **Particle systems** — a full authoring component (rate, lifetime & jitter,
  cone spread, gravity, drag, size/color over lifetime, additive/alpha, max
  pool) simulated on the CPU and rendered instanced. Live preview while
  editing; `particles_burst/emit/rate` natives from scripts.
* **Audio** — vendored [miniaudio] (public domain), initialized with a
  device when one exists and a **silent null backend when headless**, so
  servers and CI behave identically. `AudioSource` component: clip path,
  volume, loop, play-on-start, 3D spatial with min/max distance; the
  listener follows the main camera. Natives: `audio_play/stop/is_playing/
  volume`, `play_sound` one-shots.
* **Prefabs** — right-click any entity → *Save as Prefab* writes a
  `prefabs/*.prefab.json` containing that subtree; double-clicking it in the
  Assets panel (or `spawn_prefab(path)` from a script) instantiates it with
  fresh ids, remapped hierarchy, and — during Play mode — scripts started
  and audio playing. Self-test T12 covers the round trip.
* **Tags** — a free-form `tag` per entity, editable in the Inspector,
  searchable via `find_by_tag(tag)` (returns an array of ids).
* **Time scale** — `set_time_scale(s)` scales Play-mode `dt` for slow-motion
  or pause-like effects (`get_time_scale()` to read).

## 5. Editor

New Inspector sections for Particle System and Audio Source (with in-editor
audio preview), a Tag field, camera Fog controls, light "Cast Shadows",
RigidBody "Bounciness", new Add Component entries, *Save as Prefab* in the
hierarchy context menu, prefab instantiation from the Assets panel, and a
renderer-stats readout in the status bar.

## 6. Tests

`--selftest` grew from 10 to 16 checks:

* T11 particle emission/aging/reclamation
* T12 prefab save + instantiate (id remap, hierarchy, components)
* T13 `find_by_tag` through a real script VM
* T14 physics restitution
* T15 audio init + generated-WAV playback (headless-safe)
* T16 interpreter loop-frame reuse preserves escaping per-iteration state

A separate GPU smoke test (not shipped) rendered the new pipeline under
Mesa/Xvfb: 26 draws, 24 culled, 1 shader bind, 26 shadow draws, 40 particles,
zero GL errors.

# v4 — the "ecosystem" pass: PhysX-class physics, networking, baked GI, asset pipeline, hardening

The v3 notes ended by naming what an engine can't get from single features:
a real physics engine, networking, baked GI, an asset pipeline that scales,
and hardening. v4 goes at exactly that list. As always: every claim below is
tested (`--selftest`, now 30 checks) or measured on this machine.

## 1. Physics: Jolt (the real thing)

The request was PhysX. Rather than imitate one, v4 vendors and fully
integrates **Jolt Physics** — the MIT-licensed engine that shipped Horizon
Forbidden West, and PhysX's peer in the modern-engine generation. The old
~200-line AABB solver is gone; `physicsStep` now reconciles the scene into a
Jolt world every tick:

* Dynamic, kinematic, and static bodies from the same components as before
  (nothing in scenes or scripts changes), with **restitution and the new
  `friction`** property, per-body gravity toggle, mass, and sensors
  (triggers) via Jolt's sensor bodies.
* **Rotated colliders finally work** — the old engine's biggest physics
  limitation — because Jolt's solver is shape-and-orientation aware.
* **Terrain becomes a real `HeightFieldShape`**, so bodies roll and settle
  on hills through the solver instead of a post-step clamp.
* Raycasts route through Jolt's narrow-phase query; grounded detection comes
  from contact normals via a thread-safe contact listener; contact events
  keep feeding `on_collision` exactly as before.
* Multithreaded stepping through Jolt's job system.

All 8 physics-touching self-tests (gravity, contacts, triggers, restitution,
terrain rest, raycast pick, player grounding, nav-over-colliders) passed on
Jolt without loosening a single threshold.

## 2. Baked global illumination

`Lighting → Bake Lightmaps` runs a real CPU lightmapper:

* Static geometry (per-entity **Static (GI)** flag) is charted into a
  lightmap atlas — one chart per triangle, shelf-packed, edge-dilated — and
  each entity gets a `uv2`-carrying mesh clone (vertex format gained a
  second UV channel).
* Every texel raytraces a **BVH of the static scene**: direct sun with
  shadow rays, cosine-hemisphere **sky light** (colors taken from the
  procedural sky so bakes match the view), and **N bounces of indirect
  diffuse** gathered from the previous pass.
* Multithreaded across all cores; the result saves as a PNG atlas plus
  `.emmesh` clones, all referenced by the scene file, so **bakes survive
  save/load** and ship with exported games.
* Both the classic lit shader and the PBR shader consume the lightmap
  (baked diffuse replaces realtime sun diffuse + ambient; specular stays
  realtime).

Test T27 is the proof of GI, not just shadowing: a probe under a roof reads
darker than one in the open, **and re-baking with one bounce measurably adds
light back into the shadowed probe** — that added energy is indirect
illumination.

## 3. Networking

`net_host(port)` / `net_join(ip, port)` from any script (or the natives
console). The model, stated honestly: **server-authoritative snapshot
replication over UDP** —

* Joining clients receive the full scene (chunked transfer with retry, so
  scenes of any size survive UDP's datagram limit), then **20 Hz transform
  snapshots** for entities flagged `netSync` (Inspector checkbox or
  `net_sync(id, on)`), smoothed on arrival.
* Bidirectional script messaging: `net_send(text)` /
  `net_poll() -> [from, text, ...]` — clients talk to the server, the
  server broadcasts; game logic decides what messages mean.
* Spawn/despawn packets, peer timeouts, clean leave notifications.
* Cross-platform sockets (POSIX + Winsock).

Test T28 runs a real server and a real client **as two engines in one
process over loopback**: handshake, full scene transfer, position
convergence after server-side movement, and message round-trips both ways.
This is LAN-grade multiplayer — there is no client prediction, rollback, or
encryption, and the docs say so.

## 4. Asset pipeline at gigabyte scale

Three pieces, all measured on a generated **940 MB** asset set (56 noisy
2048² PNGs + a 43 MB, 500k-triangle OBJ):

* **Binary import cache** (`assets/.emcache/`): decoded textures and parsed
  models are stored as validated raw blobs keyed to the source's
  mtime+size. Warm loads skip PNG decode and Assimp entirely:

  | | cold | warm (cache) | speedup |
  |---|---|---|---|
  | 56 textures (897 MB) | 3.4 s | **0.34 s** | ~10× (24× on a cold OS page cache) |
  | 500k-tri OBJ | 1.23 s | **0.013 s** | **95×** |
  | whole set | 4.7 s | **0.38 s** | **12×** |

  Stale or corrupt entries are detected and silently rebuilt (test T25c
  literally writes garbage into the cache and asserts recovery).
* **Async texture streaming**: in the editor and player, textures appear
  instantly as placeholders while worker threads decode; finished pixels
  upload on the main thread each frame. Big scenes stop blocking the UI.
* **`.empak` archives**: `emerald-engine --pack game.empak` packs the whole
  assets folder into one seekable archive; a `game.empak` next to the assets
  folder auto-mounts, and textures load straight from it.

## 5. Hardening

* The entire 30-test suite runs **clean under AddressSanitizer +
  UndefinedBehaviorSanitizer** (that run found and fixed real bugs,
  including an argument-evaluation-order bug that silently swapped X/Z in
  network snapshots and cached animation keys).
* **Chaos test T29** feeds the engine truncated JSON, wrong-typed fields,
  hierarchy cycles, missing assets, out-of-range navigation queries,
  zero-length raycasts, nonexistent prefabs, and scripts that fail to parse
  or throw at runtime — the engine must survive all of it, and does.
  Hierarchy cycles specifically can no longer hang `worldMatrix`.
* **Atomic file writes** everywhere (`temp + rename`): a crash mid-save can
  never truncate a scene, prefab, cache entry, or config.
* **Editor autosave** every 60 s to `scenes/.autosave.scene.json`.


## Rendering: PBR + HDR

* **PBR shader** (`shaders/pbr.shader.json`, plus a skinned variant):
  Cook-Torrance GGX specular, Smith geometry, Schlick Fresnel,
  metallic/roughness/AO properties, emissive, and **normal mapping without
  precomputed tangents** (screen-space derivative cotangent frame — works on
  any imported mesh). Same shadow/fog interface as the classic lit shader;
  materials pick it by shader path, and its properties appear as sliders in
  the Inspector automatically.
* **HDR pipeline**: the scene renders into an RGBA16F target, a soft-knee
  bright pass extracts highlights at half resolution, two separable Gaussian
  blur iterations spread them, and a composite applies exposure, bloom,
  **ACES filmic tonemapping**, and gamma. Per-camera: exposure, bloom
  on/off/threshold/intensity. Works identically into editor viewports and
  the standalone player.
* **Procedural sky**: gradient dome + sun disc derived from the directional
  light, rendered after opaques (early-z). Its three colors also drive the
  PBR **hemisphere ambient**, so bounce light matches the sky.
* **Shadow texel snapping**: the shadow camera now moves in texel-sized
  steps, eliminating the edge shimmer noted in v2's known limitations.

## Animation: state machines + IK

* **AnimStateMachine component**: named states (clip, speed, loop) and
  transitions with conditions — float `>` / `<`, bool true/false, or
  one-shot triggers — evaluated every frame, with per-transition crossfade
  time. Editable in the Inspector (state list, transition rows), serialized
  with the scene, driven from scripts:
  `anim_set_float/set_bool/trigger/anim_play/anim_state`.
* **Crossfade blending**: switching clips snapshots the current pose and
  smoothstep-blends position/scale (lerp) and rotation (quaternion slerp)
  into the new clip — no pops.
* **Runtime IK**: a damped **CCD solver** (`solveCCD`) runs after animation
  sampling; scripts call `ik_reach(id, bone, x, y, z, chainLen)` to pin a
  hand/foot/look target and `ik_stop` to release. Test T19 verifies the tip
  lands within 5 cm of a reachable target.

## World: terrain + navigation

* **Terrain component**: deterministic value-noise fBm heightfield (size,
  resolution, amplitude, seed, octaves, frequency — all Inspector-editable
  with live rebuild), generated mesh with analytic normals, edge fade so
  patches sit flush. Physics treats terrain as ground (bodies rest and
  bounce on it — test T21), and scripts can query `terrain_height(x, z)`.
* **Navigation**: `nav_build(cellSize)` rasterizes static colliders into a
  walkable grid (ground slabs stay walkable, obstacles in the agent's height
  band block); `nav_path` runs A* with octile heuristic, 8-way movement
  with corner-cut prevention, and collinear simplification. Test T20 proves
  paths route around walls without touching blocked cells.

## Workflow

* **Undo/redo** (Ctrl+Z / Ctrl+Y, Edit menu): the editor snapshots the whole
  scene automatically whenever it settles after a change (gizmo drags,
  inspector edits, creates/deletes/reparents — all captured by one
  mechanism), with a 64-step history. Snapshot restore is exact (test T18).
* **Script hot-reload**: while playing, edited `.em` files are detected
  within 0.5 s and reloaded in place — iterate on gameplay without leaving
  Play mode.
* **Profiler window**: 180-frame frame-time graph with average/peak, plus
  the renderer's live counters (draws, culled, shader binds, shadow draws,
  particles, CPU ms) and nav-grid stats.

## Tests

`--selftest` grew from 16 to 22: T17 state machines + crossfade, T18
undo snapshots, T19 CCD IK convergence, T20 A* obstacle avoidance, T21
terrain heightfield + physics rest, T22 PBR shader asset round-trip.


[miniaudio]: https://miniaud.io
